package cpw.mods.fml.common.patcher;

public class ClassPatchingTransformer {

}
